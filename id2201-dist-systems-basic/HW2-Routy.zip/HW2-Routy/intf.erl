-module(intf).
-export([new/0, add/4, remove/2, lookup/2, ref/2, name/2, list/1, broadcast/2]).

new()->
    [].

add(Name,Ref,Pid,Intf)->
    [{Name,Ref,Pid}|Intf].

remove(Name,Intf)->
    lists:keydelete(Name,1,Intf).

lookup(Name, Intf)->
    Interface = lists:keyfind(Name,1,Intf),
    if 
        Interface == false ->
            notfound;
        true->
            {_,_,Pid} = Interface,
            {ok,Pid}            
        end.

ref(Name,Intf)->
    Interface = lists:keyfind(Name,1,Intf),
    if 
        Interface == false ->
            notfound;
        true->
            {_,Ref,_} = Interface,
            {ok,Ref}            
        end.

name(Ref,Intf)->
    Interface = lists:keyfind(Ref,2,Intf),
    if 
        Interface == false ->
            notfound;
        true->
            {Name,_,_} = Interface,
            {ok,Name}            
        end.

list(Intf)->
    lists:map(fun({Name,_,_})->Name end, Intf).

broadcast(Message,Intf)->
    lists:foreach(fun({_,_,Pid})->Pid!Message end, Intf).
  